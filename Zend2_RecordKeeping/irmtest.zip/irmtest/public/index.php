<?php

$_SERVER["REQUEST_URI"] = str_replace('index.php','',$_SERVER["REQUEST_URI"]);

// Define path to application directory
defined('APPLICATION_PATH') || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/../application'));
define('EOL', '<br />');
###################################
# SET ENVIRONMENT FOR GETTING DATABASE SETTINGS FROM application.ini
    
#!!!!!!!!!!! note the UK5 condition for selecting production environment !!!!!!!!!!!
# if its not uk5 you won't have db connections as staging and development settings have been cleared out in application.ini

# This is for testing what server your on
$mystring = php_uname('name');

# This is for testing what your url is
$myurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

// The !== operator can be used, cannot use !=  because the position
// of 'a' is 0. The statement (0 != false) evaluates to false.
#if (strpos($mystring, 'uk5') !== false) {


define('APPLICATION_ENV', 'production'); 
	
#}else if (strpos($mystring, 'staging') !== false) {
#	define('APPLICATION_ENV', 'development');
#}else{
#	define('APPLICATION_ENV', 'development');
#}    

#++++++++++++++++++++
#if (strpos($myurl, '.gh') !== false) { # ghana
#	define('APPLICATION_ENV1', 'productiongh');
#}elseif(strpos($myurl, '.tz') !== false) { # tanzania
#	define('APPLICATION_ENV1', 'productiontz');
#}elseif(strpos($myurl, '.ug') !== false) { # uganda
#	define('APPLICATION_ENV1', 'productionug');
#}else{ # default to kenya
#	define('APPLICATION_ENV1', 'productionke');
#}
#++++++++++++++++++++

#####################################     
// Ensure library/ is on include_path
set_include_path(implode(PATH_SEPARATOR, array(
    realpath(APPLICATION_PATH . '/../library'),
    get_include_path(),
)));

/** Zend_Application */ 
require_once 'Zend/Application.php';

// Create application, bootstrap, and run
$application = new Zend_Application(
    APPLICATION_ENV,
    APPLICATION_PATH . '/configs/application.ini'
);

$application->bootstrap()->run();