<?php

class MyLib_Logger
{ 
    public $loggerDebug;
    public $loggerAudit;
    public $loggerSys;
    public $loggerEmail;
    public $user;
    
    function __construct(){
        
        $sessionInfo = new Zend_Session_Namespace('sessionInfo');
        $this->user  = (isset($sessionInfo->loggedin))? $sessionInfo->loggedin : '';        
        
        $this->loggerDebug = Zend_Registry::get('debuglogger');
        $this->loggerAudit = Zend_Registry::get('auditlogger');

        // these are rarely used
        $this->loggerSys = Zend_Registry::get('syslogger');
        $this->loggerEmail = Zend_Registry::get('emaillogger');                
    }
}

?>
