<?php

class MyLib_Controllerbase extends Zend_Controller_Action
{ 
    #public $loggerDebug;
    #public $loggerAudit;
    #public $loggerSys;
    #public $loggerEmail;
    #public $logger;
    protected $user;
    
    public function validlogon(){       
        $sessionInfo = new Zend_Session_Namespace('sessionInfo');
        $this->user  = (isset($sessionInfo->loggedin))? $sessionInfo->loggedin : 'notLoggedOn';        

        #$this->loggerDebug = Zend_Registry::get('debuglogger');
        #$this->loggerAudit = Zend_Registry::get('auditlogger');

        // these are rarely used
        #$this->loggerSys = Zend_Registry::get('syslogger');
        #$this->loggerEmail = Zend_Registry::get('emaillogger');                
    }
    
    
    public function curlLoginAction(){
        
        $sessionInfo = new Zend_Session_Namespace('sessionInfo');
        
        if($sessionInfo->loggedin == ''){
        
        	// user may be trying to access via curl, with username and password included in curl request
        
        	# GET REQUEST OBJECT
        	$requestParams = $this->getRequest()->getParams();
        
        	$username = (isset($requestParams['username']))? $requestParams['username'] : '';
        	$password = (isset($requestParams['password']))? $requestParams['password'] : '';
        	$submit   = (isset($requestParams['submit']))?   $requestParams['submit']   : '';
        
        	if($submit == 'loginviacurl'){
        	           
        	    $sourceMapper  = new Application_Model_SourcetableMapper();
    			$validateLogin = $sourceMapper->validateLogin($username, $password);
    			 
    			if($validateLogin == 'goodlogin'){
        			# login successful, user can now view the start form
        			$sessionInfo->loggedin = $username;
    			}
        	}
        }
    }   
}

?>
