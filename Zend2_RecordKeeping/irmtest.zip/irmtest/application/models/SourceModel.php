<?php

class Application_Model_SourceModel
{

	#-------------------------------------------------------------------------------------------------------
	# This is a Zend model class. It is instantiated to create an in-memory object. The object has attributes 
	# corresponding to a record in the boot table and getters and setters required to manage these attributes.
	#
	# Data is transfered between in-memory objects and the database using a mapper class.
	# The in-memory object knows nothing about the database and does not interface to it.
	#
	# Author: Duncan Stirling
	#-------------------------------------------------------------------------------------------------------	
	
    protected $_ID;
	protected $_companyname;	
	protected $_username;
	protected $_password;
	protected $_permission;
    protected $_comment;
 
    public function __construct(array $options = null)
    {
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }

    public function __set($name, $value)
    {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid property');
        }
        $this->$method($value);
    }

    public function __get($name)
    {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid property');
        }
        return $this->$method();
    }

    public function setOptions(array $options)
    {
        $methods = get_class_methods($this);
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }
  
	#==========================================
    public function setID($text)
    {
    	$this->_ID = (string) $text;
    	return $this;
    }
    
    public function getID()
    {
    	return $this->_ID;
    }
    #==========================================  
    public function setComment($text)
    {
    	$this->_comment = (string) $text;
    	return $this;
    }
    
    public function getComment()
    {
    	return $this->_comment;
    }
    #==========================================  
    public function setCompanyname($text)
    {
    	$this->_companyname = (string) $text;
    	return $this;
    }
    
    public function getCompanyname()
    {
    	return $this->_companyname;
    }
    #========================================== 	
    public function setUsername($text)
    {
    	$this->_username = (string) $text;
    	return $this;
    }
    
    public function getUsername()
    {
    	return $this->_username;
    }
    #==========================================   
    public function setPassword($text)
    {
    	$this->_password = (string) $text;
    	return $this;
    }
    
    public function getPassword()
    {
    	return $this->_password;
    }
    #========================================== 	
    public function setPermission($text)
    {
    	$this->_permission = (string) $text;
    	return $this;
    }
    
    public function getPermission()
    {
    	return $this->_permission;
    }
    #========================================== 
                      
}

