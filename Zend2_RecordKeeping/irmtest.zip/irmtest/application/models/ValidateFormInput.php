<?php

class Application_Model_ValidateFormInput extends Application_Model_MapperBaseClass
{		
	public function validateUserInputField($userInput)
    {  
        // IS USERINPUT IMEI OR SERIAL NUMBER?
        $resultArr        = array();
        $varName          = ''; // defaults to this
        $stringLength     = strlen($userInput);
        if($stringLength == 15){ // imei
        	//-----------------------------
        	// IMEI - CHECK ITS VALID i.e. numeric
        
        	if(! is_numeric ($userInput))
        	{
        	    echo "string length 15 but input not numeric<br />";
                return FALSE; 
        	}
        	$varName = 'imei';
        }elseif($stringLength == 17){ // serial number
        	//-----------------------------
        	// SERIAL NUMBER - CHECK ITS VALID
        
        	// check it contains a hyphon
        	$haystack = $userInput;
        	$needle   = '-';
        	$pos      = strpos($haystack, $needle);
        
        	if($pos == '') {
        		//-----------------------------
        		// SERIAL NUMBER DID NOT PASS VALIDATION
        	    echo "string length 17 but did not validate as a serial number<br />";
                return FALSE; 
        	}else {
        		//-----------------------------
        		// SERIAL NUMBER VALIDATED
        		$varName = 'SerialNumber';
        	}
        }else{
            echo "String length: $stringLength, string length does not validate as a IMEI or serial number<br />";
            return FALSE; 
        }
        
        #---------------------------------------
        # USERINPUT FIELD VALID, GET SIMS RECORD

        #echo "User input valid $varName:$userInput<br />";
        $simsMapper = new Application_Model_SimstableMapper();
        $simsObj    = $simsMapper->getRecordsByField($varName, $userInput);
        
        if($simsObj == FALSE || !is_array($simsObj) || is_string($simsObj)){ 
            #echo "No sims record for $varName:$userInput.<br />"; 
            $this->logger->loggerDebug->log("$varName:$userInput NOT in sims table.", 5);            
            $resultArr['valid']    = 'notInSims';
            $resultArr['varName']  = $varName;
            $resultArr['varValue'] = $userInput;
            return $resultArr;
        }else{  
            #echo "sims record found for $varName:$userInput.<br />";
            $this->logger->loggerDebug->log("$varName:$userInput exists in sims table.", 5);
            $resultArr['serialisedSimsRecord'] = serialize($simsObj);        
            $resultArr['valid']    = 'valid';
            $resultArr['varName']  = $varName;        
            $resultArr['varValue'] = $userInput;              
            return $resultArr;           
        }
	}

	public function useValidationResultToGetMSISDN($validationResult){
	    # IF VALIDATION RETURNS AN ARRAY DATA IS IN SIMS TABLE, ELSE NEED TO USE DEVICES AND RADIPPOOL

	    $varName      = $validationResult['varName'];
	    $varValue     = $validationResult['varValue'];
	    $msisdn       = '';
	    $imei         = '';
	    $serialNumber = '';
	    $iccid        = '';
	    
	    if($validationResult['valid'] == 'valid'){
	    	$simsArr = unserialize($validationResult['serialisedSimsRecord']);
	    	$simsObj = $simsArr['0'];
	    	    		    	
	    	#echo "Your input $varName:$varValue is valid.<br />";
	    	$this->logger->loggerDebug->log("start page, user:$this->user, form input values= $varName:$varValue", 5);
	    	#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	    	# GET IMEI/MSISDN FROM SIM RECORD
	    
	    	$imei         = ($simsObj->getImei()        != '')? $simsObj->getImei()        : ''; 
	    	$msisdn       = ($simsObj->getMSISDN()      != '')? $simsObj->getMSISDN()      : ''; 
	    	$iccid        = ($simsObj->getICCID()       != '')? $simsObj->getICCID()       : ''; 
	    	$serialNumber = ($simsObj->getSerialNumber()!= '')? $simsObj->getSerialNumber(): ''; 	    	
	    	if($msisdn   == 0 || $msisdn == '' || $msisdn == FALSE){
	    		echo "Could not obtain MSISDN from sim table".EOL;
	    		$msisdn = '';
	    	}	    	
	    	#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	    	# OBTAIN MSISDN FROM SIMDATA INSTEAD

	    	if($msisdn == '' && $imei != '' && $iccid != ''){
    	    	#------------------------------------
    	    	# OBTAIN MSISDN FORM SIMDATA
    	    	    	    
	    	    echo "MSISDN is $msisdn and imei is $imei".EOL;	    	    
    	    	$simdataTableMapper = new Application_Model_SimdatatableMapper();
    	    	$simdataRecordArr   = $simdataTableMapper->getSimdataRecord('ICCID', $iccid);     	    	    	    	
    	    	$msisdn             = $simdataRecordArr['msisdn'];
    	    	#------------------------------------
    	    	# POPULATE MSISDN FIELD IN SIMS TABLE

    	    	if($msisdn > 0){
                    $this->callUpdateSim($msisdn, $iccid);              	        	    	
    	    	}   	    	
	    	}	
	    }else{
	        #echo "IMEI not in sims table, must get MSISDN from the DEVICES table.".EOL;
	    }
    	#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    	# NOT VALID BECAUSE NOT IN THE SIMS TABLE 
    	# HOWEVER IF USER ENTERED AN IMEI IT IS POSSIBLE TO PROCEED

        if(isset($imei) || $imei != ''){
            if($validationResult['varName'] == 'imei' && $validationResult['varValue'] != ''){
                $imei = $validationResult['varValue'];
            }else{
                $imei = '';
            } 
        }
        #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        # WE HAVE AN IMEI NOW TRY TO GET DEVICE THEN POOL DATA
        
    	if($imei != '' && $msisdn <= 0){
	    	# IMEI MISSING FROM SIMS - THE DATA HASN'T ARRIVED YET, USE DEVICES AND RADIPPOOL INSTEAD

	    	$radippoolMapper = new Application_Model_RadippoolMapper();
	    	$msisdn          = $radippoolMapper->useDevicesAndRadippoolToGetMSISDN($imei);

	    	if($msisdn > 0){
	    		$this->callUpdateSim($msisdn, $iccid);
	    	}else{
	    	    echo "msisdn value unavailable from sim, simdata or pool table<br />";
                return false;
	    	}
    	}
    	
    	$returnArr = array();
    	if($imei == ''){	  
	    	#echo "imei value is unavailable<br />";
        	$returnArr['imei']         = '';
        	$returnArr['msisdn']       = '';  
        	$returnArr['serialNumber'] = '';
        	return $returnArr; 
    	}
    	#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    	# WE NEED MSISDN TO PROCEED

    	
    	$returnArr['imei']         = $imei;
    	$returnArr['msisdn']       = $msisdn;  
    	$returnArr['serialNumber'] = $serialNumber;
    	return $returnArr;        
	}	
	
	function callUpdateSim($msisdn, $iccid){
    	$simtableMapper = new Application_Model_SimstableMapper();
    	$data = array(
    			'MSISDN' => $msisdn
    	);
    	$where = array(
    			'ICCID = ?' => $iccid
    	);
    	$updateResult = $simtableMapper->updateSim($data, $where);
    	#------------------------------------
    	if($updateResult == 'OK'){
    		#echo "<br />The sims table MSISDN field has been updated<br />";
    		$this->logger->loggerDebug->log("start page, user:$this->user, The sims table has been updated", 5);
    	}else{
    		#echo "<br />Unable to update sims table MSISDN field.<br />";
    		$this->logger->loggerDebug->log("start page, user:$this->user, sims table update was unsuccessful", 4);
    	}
    	return $updateResult;
	}	
}


