<?php

class Application_Model_DebugModel
{

	#-------------------------------------------------------------------------------------------------------
	# This is a Zend model class. It is instantiated to create an in-memory object. The object has attributes 
	# corresponding to a record in the boot table and getters and setters required to manage these attributes.
	#
	# Data is transfered between in-memory objects and the database using a mapper class.
	# The in-memory object knows nothing about the database and does not interface to it.
	#
	# Author: Duncan Stirling
	#-------------------------------------------------------------------------------------------------------	
	
    protected $_ID;
    protected $_imei;
    protected $_status;
    protected $_debug;
    protected $_errorcodes;
    protected $_recordtime;
    protected $_receivetime; 
    protected $_LastUpdated;       
    
    public function __construct(array $options = null)
    {
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }

    public function __set($name, $value)
    {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid property');
        }
        $this->$method($value);
    }

    public function __get($name)
    {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid property');
        }
        return $this->$method();
    }

    public function setOptions(array $options)
    {
        $methods = get_class_methods($this);
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }
	#==========================================
    public function setStatus($text)
    {
    	$this->_status = (string) $text;
    	return $this;
    }
    
    public function getStatus()
    {
    	return $this->_status;
    }
    #==========================================
    public function setDebug($text)
    {
    	$this->_debug = (string) $text;
    	return $this;
    }
    
    public function getDebug()
    {
    	return $this->_debug;
    }    
    
    #==========================================
    public function setErrorcodes($text)
    {
    	$this->_errorcodes = (string) $text;
    	return $this;
    }
    
    public function getErrorcodes()
    {
    	return $this->_errorcodes;
    }    

    #========================================== 
    public function setID($text)
    {
    	$this->_ID = (string) $text;
    	return $this;
    }
    
    public function getID()
    {
    	return $this->_ID;
    }
    #==========================================
    public function setImei($text)
    {
    	$this->_imei = (string) $text;
    	return $this;
    }
    
    public function getImei()
    {
    	return $this->_imei;
    }
    #==========================================    
    public function setRecordtime($text)
    {
    	$this->_recordtime = (string) $text;
    	return $this;
    }
    
    public function getRecordtime()
    {
    	return $this->_recordtime;
    }
    #==========================================    
    public function setReceivetime($text)
    {
    	$this->_receivetime = (string) $text;
    	return $this;
    }
    
    public function getReceivetime()
    {
    	return $this->_receivetime;
    }
    #==========================================    
    public function setLastUpdated($text)
    {
    	$this->_LastUpdated = (string) $text;
    	return $this;
    }
    
    public function getLastUpdated()
    {
    	return $this->_LastUpdated;
    }
    #==========================================    
}

