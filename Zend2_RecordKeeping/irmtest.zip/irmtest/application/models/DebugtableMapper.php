<?php

class Application_Model_DebugtableMapper extends Application_Model_MapperBaseClass
{		
	protected $dbTable = 'Application_Model_DbTable_Debug';
	# logger and user are attributes in baseclass	

	public function getRecordsByMonth($from, $to, $imei='')
	{	
		$to = $to.' 24:00:00';
		$from = $from.' 00:00:00';
		        
		
		
		
    	try{
    		$result = $this->getDbTable($this->dbTable)->select()->from('debug', array('ID', 'imei', 'status', 'debug', 'errorcodes', 'recordtime', 'receivetime', 'LastUpdated'))
			->where('LastUpdated > ?', $from)
			->where('LastUpdated < ?', $to)
			->order('LastUpdated DESC') // tells the latest date first
			->limit(100, 0); //first 100 skipping 0 records
    		
    		// BY DATE
    		if($imei == ''){
        		$result = $this->getDbTable($this->dbTable)->select()->from('debug', array('ID', 'imei', 'status', 'debug', 'errorcodes', 'recordtime', 'receivetime', 'LastUpdated'))
    			->where('LastUpdated > ?', $from)
    			->where('LastUpdated < ?', $to)
    			->order('LastUpdated DESC') // tells the latest date first
    			->limit(100, 0); //first 100 skipping 0 records
    			 
    		}else{
        		$result = $this->getDbTable($this->dbTable)->select()->from('debug', array('ID', 'imei', 'status', 'debug', 'errorcodes', 'recordtime', 'receivetime', 'LastUpdated'))
    			->where('LastUpdated > ?', $from)
    			->where('LastUpdated < ?', $to)
    			->where('imei        = ?', $imei)			
    			->order('LastUpdated DESC') // tells the latest date first
    			->limit(100, 0); //first 100 skipping 0 records
    		}    		    		
   
    	}catch(Exception $e){
    		// Query Failed
    		print_r($e);
    		$this->logger->loggerDebug->log("failed to get monthly event records, user:$this->user", 4);
    			
    		#		    $this->loggerDebug->log('Failed to select from messageid table.',  PEAR_LOG_EMERG);
    		#		   	$this->loggerDebug->log('Error no: '     .$e->getCode(),    PEAR_LOG_EMERG);
    		#		   	$this->loggerDebug->log('Error message: '.$e->getMessage(), PEAR_LOG_EMERG);
    		#		   	$this->loggerDebug->log('Error in file: '.$e->getFile(),    PEAR_LOG_EMERG);
    		#		   	$this->loggerDebug->log('Line in file: ' .$e->getLine(),    PEAR_LOG_EMERG);
    		#		   	$this->loggerDebug->log('Trace info: '   .$e->getTrace(),   PEAR_LOG_EMERG);
    		return false;
    	}
    
		// return all relevant rows
		$entriesArr = array();
		$rowset = $this->getDbTable($this->dbTable)->fetchAll($result);

		if(($rowset != false) && (count($rowset) != 0)){

		    foreach($rowset as $row){
			// return CustomerID, Packet, Status
				$entry = new Application_Model_DebugModel();
				
				$entry->setID($row->ID);
				$entry->setImei($row->imei);
				$entry->setStatus($row->status);
				$entry->setDebug($row->debug);
				$entry->setErrorcodes($row->errorcodes);
				$entry->setRecordtime($row->recordtime);								
				$entry->setReceivetime($row->receivetime);
				$entry->setLastUpdated($row->LastUpdated);
				
				$entriesArr[] = $entry;
			}
			return $entriesArr;
		}else{
    		$this->logger->loggerDebug->log("no monthly event records, user:$this->user", 4);
    		return false;
		}					
	}
}