<?php

class Application_Model_DbTable_Sims extends Zend_Db_Table_Abstract
{
	#-------------------------------------------------------------------
	# Istantiate this to create a database connection to the ififo table
	#
	# Author: Duncan Stirling
	#-------------------------------------------------------------------	
	
    protected $_name   = 'sims';
    #protected $_schema = 'ibis';
    #protected $_schema = 'crake';   
}
