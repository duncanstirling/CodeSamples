<?php

class Application_Model_DbTable_Status extends Zend_Db_Table_Abstract
{
	#-------------------------------------------------------------------
	# Istantiate this to create a database connection to the ififo table
	#
	# Author: Duncan Stirling
	#-------------------------------------------------------------------	
	
    protected $_name   = 'status';
    #protected $_schema = 'ibis';
    #protected $_schema = 'crake';   
}
