<?php

class Application_Model_MapperBaseClass
{    	
#----------------------------------------------------------------
# Some zend mapper classes are extending this class
# It contains some common functionality for all mapper classes
# This was formerly the DataItem class
#	
# It is used for logging messages and create database connections
# 
# author: Duncan Stirling
#----------------------------------------------------------------		
	
	public $logger;
	public $user;
		
	function __construct() {
		$this->logger = new MyLib_Logger();
		$this->user = $this->logger->user;
		#$this->logger->loggerDebug->log("xxxxx user:$this->user", 4);
		#$this->logger->loggerAudit->log("xxxxx user:$this->user", 5);		
	}
	
	public function processErrors($e, $data, $logLevel=''){
/*	    
	    
		# logging at default level, if higher priority logging wanted pass in a value for $logLevel
		if($logLevel == ''){
			$config           = Zend_Controller_Front::getInstance()->getParam('bootstrap');
			$quickbookOptions = $config->getOption('resources');  #resources.frontController.params.starling.defaultThreshold
			$logLevel         = $quickbookOptions['frontController']['params']['starling']['defaultThreshold'];
		}
		#################################################################
		# STORING REJECTED RECORDS, NO ERROR AVAILABLE
	
		# if $e is not an object, its a rejected record, data is a string and loglevel is 6
		if (!is_object($e)) {
		    $this->logger->log($data, $logLevel);
		    return;
    	}
    	#################################################################
		if(is_array($data)){
		    $problem = $data['reason'];
    	}else{
    	    echo $e->getMessage(); # fixme this needs logging somewhere
		    $problem =  $data;
    	}
    	echo $problem.', Error message: '.$e->getMessage();
    	$this->logger->log('Problem: '      .$problem,         $logLevel);
    	$this->logger->log('Error no: '     .$e->getCode(),    $logLevel);
    	$this->logger->log('Error message: '.$e->getMessage(), $logLevel);
    	$this->logger->log('Error in file: '.$e->getFile(),    $logLevel);
    	$this->logger->log('Line in file: ' .$e->getLine(),    $logLevel);
    	$this->logger->log('Trace info: '   .$e->getTrace(),   $logLevel);
    	
    	if($e->getMessage() == 'SQLSTATE[HY000]: General error: 2006 MySQL server has gone away'){
    	    Application_Model_MapperBaseClass::closeDBConnection();
    	}
*/    	
    	return;
	}	
	
	public function setDbTable($dbTable)
	{
		# Application/Model/DbTable/Devices ~ this is an instance of Zend_Db_Table_Abstract
		# where $_name = 'devices' is set
		# get an instance of it and call it $dbTable
		
		if (is_string($dbTable)) {
			$dbTable = new $dbTable();
		}else{
			echo 'cannot create instance';
		}
		
		if (!$dbTable instanceof Zend_Db_Table_Abstract) {
			throw new Exception('Invalid table data gateway provided');
		}
		
		$this->_dbTable = $dbTable;
		return $this;
	}
	
	public function getDbTable($pathToTable)
	{
		$this->_dbTable = null;		
		#if (null === $this->_dbTable) {
			$this->setDbTable($pathToTable);		
		#}
	
		# return $dbTable got in setDbTable

		return $this->_dbTable;
	}	
}

