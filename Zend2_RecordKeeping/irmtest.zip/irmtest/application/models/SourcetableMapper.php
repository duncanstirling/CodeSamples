<?php

class Application_Model_SourcetableMapper extends Application_Model_MapperBaseClass
{		
	protected $dbTable = 'Application_Model_DbTable_Source';
	# logger and user are attributes in baseclass
	
	public function validateIp($ip)
	{
	    
	    $sessionInfo = new Zend_Session_Namespace('sessionInfo');
    	$username = $sessionInfo->loggedin; 

		try{	
		    $result = $this->getDbTable($this->dbTable)->select()->from('source', array('ID', 'comment'))
                                                   ->where('username = ?', $username);									   										   
		}catch(Exception $e){
		    print_r($e);
		   	// Query Failed
		    #$this->loggerDebug->log('Failed to select from messageid table.',  PEAR_LOG_EMERG);
#		   	$this->loggerDebug->log('Error no: '     .$e->getCode(),    PEAR_LOG_EMERG);
#		   	$this->loggerDebug->log('Error message: '.$e->getMessage(), PEAR_LOG_EMERG);
#		   	$this->loggerDebug->log('Error in file: '.$e->getFile(),    PEAR_LOG_EMERG);
#		   	$this->loggerDebug->log('Line in file: ' .$e->getLine(),    PEAR_LOG_EMERG);
#		   	$this->loggerDebug->log('Trace info: '   .$e->getTrace(),   PEAR_LOG_EMERG);
		    $this->logger->loggerDebug->log("error selecting from source, user:$this->user", 4);
		   	return false;
		}		

		if(isset($result)){			    	    
		    $row = $this->getDbTable($this->dbTable)->fetchRow($result);
 
			$sourceObj = new Application_Model_SourceModel();						
			$sourceObj->setID($row['ID']); 
			$sourceObj->setIP($row['IP']);			
			$sourceObj->setComment($row['comment']); 
		
			
			if($sourceObj->getIP() == $ip || $sourceObj->getIP() == ''){  			
			    return 'goodip';
			}
			
		}else{
		    $this->logger->loggerDebug->log("select from source, no rows returned, user:$this->user", 4);
		    return 'badip';
		}
	}		
    #===================================================================================
    
	public function validateLogin($requestParams)
	{	
	    $sessionInfo = new Zend_Session_Namespace('sessionInfo');
		#echo "<pre>", print_r($requestParams, 1), "<pre>";

		$username    = $requestParams['username'];
		$password    = $requestParams['password'];
		$companyname = $requestParams['companyname'];
		#================================================================			
		try{
			$result = $this->getDbTable($this->dbTable)->select()->from('source', array('ID', 'companyname', 'username', 'password', 'permission', 'comment'))
			->where(
			        'username = ?', $username	        
			);
		}catch(Exception $e){
			echo "<pre>", print_r($e->getMessage(), 1), "</pre>";
			// Query Failed
			#           $this->loggerDebug->log('Failed to select from messageid table.',  PEAR_LOG_EMERG);
			#		   	$this->loggerDebug->log('Error no: '     .$e->getCode(),    PEAR_LOG_EMERG);
			#		   	$this->loggerDebug->log('Error message: '.$e->getMessage(), PEAR_LOG_EMERG);
			#		   	$this->loggerDebug->log('Error in file: '.$e->getFile(),    PEAR_LOG_EMERG);
			#		   	$this->loggerDebug->log('Line in file: ' .$e->getLine(),    PEAR_LOG_EMERG);
			#		   	$this->loggerDebug->log('Trace info: '   .$e->getTrace(),   PEAR_LOG_EMERG);
			
			$this->logger->loggerDebug->log("error selecting from source, user:$this->user", 4);
			return false;
		}
		#================================================================		
		# MD5 ENCRYPTED PASSWORD
		
		$passwordMD5 = md5($password);		
		#------------------------------	
		# SHA256 ENCRYPTED PASSWORD
		
		$salt         = $password;	
		$passwordSHA2 = hash('sha256', $password.$salt);
		$passwordMD5  = md5($password);
		#================================================================	
		# EXTRACT THE USERS RECORD
		
		#$rowset = $this->getDbTable($this->dbTable)->fetchAll($result);
		$row = $this->getDbTable($this->dbTable)->fetchRow($result);
		if(($row != false) ){

			$sourceObj = new Application_Model_SourceModel();
			$sourceObj->setPassword($row['password']);
			$sourceObj->setCompanyname($row['companyname']);  
			$sourceObj->setUsername($row['username']);		
			$sourceObj->setPermission($row['permission']);					
			#===================================================
			# THE PASSWORD IS SHA2 HASHED AND CORRECT
			
			if($sourceObj->getPermission() == 'active' && $sourceObj->getCompanyname() == $companyname  && $sourceObj->getUsername() == $username && $sourceObj->getPassword() == $passwordSHA2){
			    
			    // the password is sha2 hashed and correct		    
			    $sessionInfo->permission = $sourceObj->getPermission();			 

				echo EOL.'Logon valid.'.EOL;
				$sessionInfo->permission = 'active';
				return true;
				
			}elseif	($sourceObj->getPermission() == 'active' && $sourceObj->getCompanyname() == $companyname && $sourceObj->getUsername() == $username && $sourceObj->getPassword() == $passwordMD5){
				# THE PASSWORD IS MD5 HASHED - UPDATE THE PASSWORD TO BE SHA2 HASHED
			
				echo EOL.'Password security needs to be updated.'.EOL;
				$data = array(
					'password'     => $passwordSHA2                      		
				);                      
				$where = array(
					'username = ?' => $username
				);
				
				try{
					$result = $this->getDbTable($this->dbTable)->update($data, $where);						
				}catch(Exception $e){
					// Update Failed
					#$error = $this->__db->get_error();
		#			$this->loggerDebug->log('Failed to update devices table.',  PEAR_LOG_DEBUG);
		#			$this->loggerDebug->log('Error no: '     .$e->getCode(),    PEAR_LOG_DEBUG);
		#			$this->loggerDebug->log('Error message: '.$e->getMessage(), PEAR_LOG_DEBUG);
		#			$this->loggerDebug->log('Error in file: '.$e->getFile(),    PEAR_LOG_DEBUG);
		#			$this->loggerDebug->log('Line in file: ' .$e->getLine(),    PEAR_LOG_DEBUG);
		#			$this->loggerDebug->log('Trace info: '   .$e->getTrace(),   PEAR_LOG_DEBUG);
					$this->logger->loggerDebug->log("error updating radippool, user:$this->user", 4);
					echo $e->getMessage()."<br />";
					return false;
				}

				if($result == 1){
					echo EOL.'The password encryption has been updated.'.EOL;
					$sessionInfo->permission = 'active';
					return true;						
				}		
			}else{
				# LOGIN FAILURE - NO PASSWORD MATCH
				
				echo 'The password is not correct.';			
				return false;
			}				
		}else{
			# LOGIN FAILED - NO RECORD MATCH - THE USER HAS NOT REGISTERED 

			echo 'This user is not registered';
			$dateTime = date('m/d/Y h:i:s a', time());
			$this->logger->loggerDebug->log("$username failed to logon at $dateTime", 4);
			// bad logon so no permission
			return false;
		}
	}		
}
