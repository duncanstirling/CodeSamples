<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    
    protected function _initTimeZone() {
    	date_default_timezone_set('UTC');
    }    
    
    protected function _initLog() {

        $options = $this->getOption('resources'); 
     	#----------------------------------------------------
     	// LOG DEBUG
    	     
        $partitionConfig = $this->getOption('log');
        $logOptions = $options['log'];      
        $baseFilename = $logOptions['stream']['writerParams']['stream'];
         
        if ($partitionConfig['partitionStrategy'] == 'context'){
        	$baseFilename = $partitionConfig['path'].'/'.APPLICATION_ENV.'_DEBUG';
        }
       
        date_default_timezone_set('UTC');
        $logFilename = '';
         
        /*
         * NOT USING THIS, USING LOGROTATE INSTEAD
        switch(strtolower($partitionConfig['partitionFrequency'])){
        	case 'daily':
        		$logFilename = $baseFilename.'_'.date('Y_m_d');
        		break;
        
        	case 'weekly':
        		$logFilename = $baseFilename.'_'.date('Y_W');
        		break;
        
        	case 'monthly':
        		$logFilename = $baseFilename.'_'.date('Y_m');
        		break;
        
        	case 'yearly':
        		$logFilename = $baseFilename.'_'.date('Y');
        		break;
        
        	default:
        		$logFilename = $baseFilename;
        }
        */
        
        // LOGROTATE KEEP 7 DAYS OF FILES AND NUMBER THEM
        $logFilename = $baseFilename.'.log';
        
        $logOptions['stream']['writerParams']['stream'] = $logFilename;
        $logger = Zend_Log::factory($logOptions);
        Zend_Registry::set('debuglogger', $logger);       
    	#----------------------------------------------------    
    	// LOG AUDIT
    	
    	$partitionConfig = $this->getOption('log');
    	$logOptions = $options['log'];    	
    	$baseFilename = $logOptions['stream']['writerParams']['stream'];
    	 
    	if ($partitionConfig['partitionStrategy'] == 'context'){
    		$baseFilename = $partitionConfig['path'].'/'.APPLICATION_ENV.'_AUDIT';
    	}
    	
    	date_default_timezone_set('UTC');
    	$logFilename = '';
    	 
    	/*
    	 * LOG ROTATE WILL NUMBER THE FILES INSTEAD
    	switch(strtolower($partitionConfig['partitionFrequency'])){
    		case 'daily':
    			$logFilename = $baseFilename.'_'.date('Y_m_d');
    			break;
    	
    		case 'weekly':
    			$logFilename = $baseFilename.'_'.date('Y_W');
    			break;
    	
    		case 'monthly':
    			$logFilename = $baseFilename.'_'.date('Y_m');
    			break;
    	
    		case 'yearly':
    			$logFilename = $baseFilename.'_'.date('Y');
    			break;
    	
    		default:
    			$logFilename = $baseFilename;
    	}
    	*/
    	
    	// LOGROTATE KEEP 7 DAYS OF FILES AND NUMBER THEM
    	$logFilename = $baseFilename.'.log';
    	
    	$logOptions['stream']['writerParams']['stream'] = $logFilename;    	
    	$logger = Zend_Log::factory($logOptions);
    	Zend_Registry::set('auditlogger', $logger);       	 	
		#----------------------------------------------------
		// WRITE TO SYSLOG
		
		// using syslog to write everything to /var/log/debug
		// pass writer the application name
		$writer = new Zend_Log_Writer_Syslog(array('application' => 'IBIS'));	
		// set the threshold for recording logs
	    $writer->addFilter(6);
		$logger = new Zend_Log($writer);				
		Zend_Registry::set('syslogger', $logger);
		#----------------------------------------------------		
		// WRITE TO EMAIL
		
		$mail = new Zend_Mail();
		$mail->setFrom('ibis@eseye.com')
		->addTo('dstirling@eseye.com');#

		$writer = new Zend_Log_Writer_Mail($mail);
		
		// Set subject text for use; summary of number of errors is appended to the
		// subject line before sending the message.
		$writer->setSubjectPrependText('Error in updating POST table');		
		
		// Only email warning level entries and higher.
		$writer->addFilter(Zend_Log::DEBUG);		
		$emailLogger = new Zend_Log($writer);
		Zend_Registry::set('emaillogger', $emailLogger);
		#----------------------------------------------------
		// AUTOLOAD LOGGING LIBRARY IN EVERY CONTROLLER
		
		$autoloader = Zend_Loader_Autoloader::getInstance();
		$autoloader->registerNamespace('MyLib_');
	
	}
		
    public function _initDbRegistry()
    {
        $this->bootstrap('multidb');
        $multidb = $this->getPluginResource('multidb');
        Zend_Registry::set('db_maindb',      $multidb->getDb('maindb'));
    }   
}
