<?php
# FOR STORING PASSWORDS IN DATABASE MANUALLY DO THIS:
# update `source` set password = MD5('testpass') where username = 'testuser'
# http://ibis.eseye.net/index?username=testuser&password=testpass&submit=Login
# http://duncanvm/IBISHelperPages/public/index.php/index

#class IndexController extends Zend_Controller_Action
class IndexController extends MyLib_Controllerbase
{
    // look in base class
    public $logger;
    public $user;
    
    public function init()
    {
        // look in base class
        #$this->logger = new MyLib_Logger();
        #$this->user   = $this->logger->user; 
		$this->user    = $this->validlogon();		
    }    
    //==============================================
    public function ipAction(){        
        /*$requestParams = $this->getRequest()->getParams();
        $ip = $requestParams['ip'];
                
        $sourceMapper = new Application_Model_SourcetableMapper();
        $validateIp   = $sourceMapper->validateIp($ip);

        // prevents page formatting being returned
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);  
        echo "$validateIp";*/
    }
    //==============================================
    public function validatePassword()
    { 	
		# After implementing the algorithm, when the user logs in with valid credentials, update the stored password in the DB with the new algorithm.
		
		
		# user logs in with username and password
		
		
		# previously used md5, however from now on, sha2 instead
		
		
		# if sha2 field not populated, compare db md5 value with md5 encrypted password entered and populate sha2 field
		
		
		# if sha2 field is populated, ignore md5 field and compare db sha2 value sha2 encrypted entered password 
		
		
		# if user is validated, populate the session and notify them of successful
		
		
		# user not validated, end with notification

		return; #fixme remove	
	}
	
    public function indexAction()
    {        
        $sessionInfo = new Zend_Session_Namespace('sessionInfo');
		
		#echo "Required: ZF1.12, MySQL 5.6.x , PHP 5.6.x, Apache 2.2.x";		
		#echo EOL.'PHP version: '.phpversion();
		#echo EOL.'Apache version: '.apache_get_version(); 
		#echo EOL.'Zend version: '.zend_version();
		#echo EOL.'MYSQL version: '.mysql_get_client_info();        				
		####################################################
        // this page is so can indicate on index page without overwritting currentPage
        // on all but index page, thisPage and currentPage will be the same
        $sessionInfo->thisPage = 'index'; 
        $request = $this->getRequest();         
        //==================================== 
        // LOGIN VIA GET: API CURL 
        
        $this->curlLoginAction();		
        //====================================  
        // LOGIN VIA POST: FORM INPUT                
     
        if(!isset($sessionInfo->loggedin) || ($sessionInfo->loggedin == '')){
            $form = new Application_Form_Login();

            // storing password UPDATE source SET PASSWORD = MD5( "$PASSWORD" ) where username = ""             
            $requestParams = $request->getParams();                      
            $usernameinput = (isset($requestParams['username']))? $requestParams['username'] : '';
            $password      = (isset($requestParams['password']))? $requestParams['password'] : '';
            $submit        = (isset($requestParams['submit']))?   $requestParams['submit']   : '';            

            // showing login screen
            $this->view->title = 'Login Page';                      
            //====================================    
            if($submit == 'Login'){

                // validate form input
                if ($form->isValid($request->getParams())) { 

                    $sourceMapper  = new Application_Model_SourcetableMapper();
                    $validateLogin = $sourceMapper->validateLogin($requestParams);

                    if($validateLogin === true){

                        # login successful, user can now view the start form
                        $sessionInfo->loggedin = $usernameinput; 
                                              
                        #$this->logger->loggerAudit->log("start page, user:$usernameinput, login successful", 5);
                                                
                        # if the user has come from this page don't redirect and if the user has come from logout page don't redirect back to originating page
                        if($sessionInfo->currentPage != '' && $sessionInfo->currentPage != 'logout')
                        {
                            $this->_response->setRedirect("./$sessionInfo->currentPage");
                        }
                                                
                    }else{

                        # $this->logger->loggerDebug->log("start page, user:$usernameinput, login failed", 4);                        
                                            
                        // login failed 
                        $this->view->loginstatus = 'Your login was unsuccessful.';
                        $this->view->form = $form;
                        #$form->reset();
                        return;
                    }
                  
                }else{
                    // form not valid don't proceed                
                    $this->view->form = $form;
                    return;
                }
            }else{

                // user has arrived at the page for first time
                // session not set and login not attempted
                
                // if div with output message is empty it remains empty
                // to control when message put out ie no message on login screen    

                $this->view->form = $form;    
                return;
            }                       
        }
        //====================================  
        # BEFORE PROCEEDING CHECK USER HAS PERMISSION TO USE THIS PAGE
        
        $sessionInfo = new Zend_Session_Namespace('sessionInfo');
        $permissionsMessage =  "Your permissions are $sessionInfo->permission.<br />";
        
        /*
        $haystack = $sessionInfo->permission;
        $needle   = 'test';
        $pos = strpos($haystack, $needle);

        if ($pos === false) {
            $this->logger->loggerDebug->log("start page: permission denied to use the start page, user:$this->user", 4);                        
        	$this->_response->setRedirect('./accessdenied');
        }  
        */          

        // showing start page
        $this->view->title = 'Landing page for logged in users';

        # action body        
        $form = '';        
        ######################################################################################################
        #                             **** PROCESS START FORM INPUT ****
        ######################################################################################################
   
        $requestParams = $this->getRequest()->getParams();
        $userInput     = (isset($requestParams['imei']))   ? $requestParams['imei']   : '';
        $timeInterval  = (isset($requestParams['ttl']))    ? $requestParams['ttl']    : '';        
        $submit        = (isset($requestParams['submit'])) ? $requestParams['submit'] : '';

        // time interval is numeric
        if($timeInterval !='' && !is_numeric($timeInterval)){
        	#echo "PROBLEM: You can only enter a numeric time interval<br />";
        	echo 'FAILED';
        	return FALSE;
        }

        // check if the form should be validated, ie check if submit button pressed or its value set via curl 
        if(($submit == 'enter' || $submit == 'loginviacurl') && $sessionInfo->loggedin != ''){  
            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            // FOR CURL ACCESS
            
            // put this before last statement to prevent unwanted formatting and print statements in curl feedback
            if($submit == 'loginviacurl'){
            	$this->_helper->layout()->disableLayout();
            	$this->_helper->viewRenderer->setNoRender(true);
            	ob_clean();
            }
            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                    
            # CHECK FORM VALIDATES THE INPUT - APPLIES TO INPUT VIA CURL OR THE FORM
            
            if (!$form->isValid($request->getParams())) {                
                #echo "User input <u>NOT</u> valid, form validation failed.";
                echo 'FAILED';
            	return;
            }else{                    
                #%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%
                // VALIDATE USERINPUT INPUT FIELD (THIS CAN BE IMEI OR SERIAL NUMBER)
                
                #echo "<br /><b>Result of form processing:</b><br />";
                $validateUserInput = new Application_Model_ValidateFormInput();
                $validationResult  = $validateUserInput->validateUserInputField($userInput);
                 
                if($validationResult == FALSE){
                	#echo "User input validation failed.<br />";
                	echo 'FAILED';
                	return;
                }
                
                // IDEALLY VALIDATIONRESULT WILL CONTAIN A SIMS RECORD
                $obtainMSISDNArr = $validateUserInput->useValidationResultToGetMSISDN($validationResult);
                
                if($obtainMSISDNArr == FALSE){
                    echo 'FAILED';
                	return FALSE;
                }
                $imei   = $obtainMSISDNArr['imei'];
                $msisdn = $obtainMSISDNArr['msisdn'];                
                #%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%=%	
            	# EXPIRE OLD OFIFO RECORD
            		
            	# expire any unprocessed ofifo messages, ie where status <= 0
            	# add credit to new record
            	
            	$ofifoMapper           = new Application_Model_OfifotableMapper();
            	#$cutomerID_arr        = array('state', 'combined', 'credit');
            	$cutomerID_arr         = ''; // this is for when a message with any customerid is expired
            	$unprocessedRecordInfo = $ofifoMapper->expireRecordAndReturnUnprocessedCredit($msisdn, $cutomerID_arr);
            	#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%					
            	# INSERT
               
            	// insert new record into ofifo, ie not carrying any expired credit forward                   
            	$CustomerID      = 'combined';
            	$ClassID         = 'ibis';
            	$DeviceID        = $msisdn;
            	$DestinationType = 'udp';
            	$DestinationDesc = $imei;
            
            	// packet
            	$packet  = chr(0x62);
            	$packet .= chr(0x01);
            	$packet .= chr(0x02); // State
            	$packet .= chr(0x60);                   
            	$packet .= chr(0x01);
            	$packet .= chr(0x01); // Credit			   
            
            	// status 
            	$status = 0;                   
                                  
#echo "CustomerID:$CustomerID, ClassID:$ClassID, DeviceID:$DeviceID, DestinationType:$DestinationType, DestinationDesc:$DestinationDesc, packet:$packet, status:$status, timeInterval:$timeInterval";                		
            	$insertRecord = $ofifoMapper->insertOfifo($CustomerID, $ClassID, $DeviceID, $DestinationType, $DestinationDesc, $packet, $status, $timeInterval);            	            	
            	#echo "Result of inserting OFIFO record: ";
            	if($insertRecord == 'OK'){
               	    echo 'OK';
               	    $this->logger->loggerAudit->log("start page, user:$this->user, new OFIFO record: customerID:$CustomerID, ClassID:$ClassID, DeviceID:$DeviceID, DestinationType:$DestinationType, DestinationDesc:$DestinationDesc, packet:$packet, status:$status, timeInterval:$timeInterval", 5);               	    
            	}else{
                   echo 'FAILED';
                   $this->logger->loggerDebug->log("start page, user:$this->user, Failed to insert new record into ofifo", 4);                       
            	}                                 
            }            
         }    
        ######################################################################################################
        #                                **** END PROCESS STOP FORM INPUT ****
        ###################################################################################################### 
    
         // the form always needs to be cleared, doesn't stop it showing validation messages
		if(isset($form)){
			 if($form != ''){
				 $form->reset();
				 $this->view->form = $form;  
			 }else{
				 $this->view->form = '';
			 }				 
		}		 
    }
    //==============================================
}

