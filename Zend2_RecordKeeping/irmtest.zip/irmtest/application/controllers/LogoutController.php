<?php

class LogoutController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // end login by removeing loggedin value
        $sessionInfo = new Zend_Session_Namespace('sessionInfo');
        $sessionInfo->loggedin = '';
        
        // redirect to login page
        // want to to redirect back to the start page after, as a default page
        // so current page set to start page
        $sessionInfo->currentPage = 'logout';
        $sessionInfo->permission  = 'test';
        $this->_response->setRedirect('./index');
    }
}

