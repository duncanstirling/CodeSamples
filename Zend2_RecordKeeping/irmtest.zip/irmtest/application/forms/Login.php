<?php

class Application_Form_Login extends Zend_Form
{
    public function init()
    {
    	// after the initial log in, all other posting is handled by ajax
    	$this->setMethod('get');
    
    	// Set the form name
    	$this->setName('form_signin');
    
    	// Add an company element
    	$this->addElement('text', 'companyname', array(
    			'label'      => 'Your company name:',
    			'required'   => true,
				'class'      => 'login',
    			'validators' => array(
    					array('validator' => 'StringLength', 'options' => array(0, 50))
    			),
    			'id' =>'companyname'
    	));	
	
    	// Add an username element
    	$this->addElement('text', 'username', array(
    			'label'      => 'Your username:',
    			'required'   => true,
				'class'      => 'login',
    			'validators' => array(
    					array('validator' => 'StringLength', 'options' => array(0, 20))
    			),
    			'id' =>'username'
    	));
    
    	// Add an password element
    	$password = $this->addElement('password', 'password', array(
    			'filters'    => array('StringTrim'),
    			'validators' => array( array(
    					'StringLength', false, array(5,35,'messages' => array(
    							Zend_Validate_StringLength::TOO_SHORT => 'Your password is too short.',
    							Zend_Validate_StringLength::TOO_LONG => 'Your password is too long.',
    					)))),
    			'required' => true,
				'class'    =>'login',
    			'label'    => 'Your password:',
    			'id'       =>'password'
    	));
    
    	// Add the submit button
    	$this->addElement('submit', 'submit', array(
    			'ignore'   => true,
    			'label'    => 'Login',
				'disabled'=>'disabled'
    	));
    
    	// And finally add some CSRF protection - removed this so can log in using curl
    	#$this->addElement('hash', 'csrf', array(
    	#		'ignore' => true,
    	#));
    }
}

